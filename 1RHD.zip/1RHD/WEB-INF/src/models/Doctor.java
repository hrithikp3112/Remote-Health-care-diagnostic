package models;

import java.sql.*;
import java.util.*;
public class Doctor{
	private String specilization;
	private String doctorName;
	private String docFees;
	private String address;
	private String contactno;
	private String id;
	private String docEmail;
	private String password;
	private String creationString;
	private String updationString;

	public String getSpecilization(){
		return specilization;
	}

	public void setSpecilization(String specilization){
		this.specilization=specilization;
	}

	public String getDoctorname(){
		return doctorName;
	}

	public void setDoctorname(String doctorName){
		this.doctorName=doctorName;
	}

	public String getAddress(){
		return address;
	}

	public void setAddress(String address){
		this.address=address;
	}
	public String getDocfees(){
		return docFees;
	}

	public void setDocfees(String docFees){
		this.docFees=docFees;
	}

	public String getContactno(){
		return contactno;
	}

	public void setContactno(String contactno){
		this.contactno=contactno;
	}
	public String getId(){
		return  id;
	}

	public void setId(String id){
		this.id=id;
	}


	public String getDocemail(){
		return docEmail;
	}

	public void setDocemail(String docEmail){
		this.docEmail=docEmail;
	}

	public String getPassword(){
		return password;
	}

	public void setPassword(String password){
		this.password=password;
	}

	public String getCreationString(){
		return creationString;
	}

	public void setCreationString(String creationString){
		this.creationString=creationString;
	}

	public String getUpdationString(){
		return updationString;
	}

	public void setUpdationString(String updationString){
		this.updationString=updationString;
	}

	public void registerDoctor(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms?user=root&password=1234");
			
			String q1 = "insert into doctors (id,specilization,";
			String q2 = "doctorName,address,docFees,contactno,docEmail,";
			String q3 = "password) value ";
			String q4 = "(?,?,?,?,?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(q1+q2+q3+q4);
			
			ps.setString(1,id);
			
			ps.setString(2,specilization);
			ps.setString(3,doctorName);
			ps.setString(4,address);
			ps.setString(5,docFees);
			ps.setString(6,contactno);
			ps.setString(7,docEmail);
			ps.setString(8,password);
			
			ps.executeUpdate();

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}


	public boolean loginDoctor(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select * from doctors where email=? and password=?";

			PreparedStatement ps = con.prepareStatement(q1);
			ps.setString(1,docEmail);
			ps.setString(2,password);

			ResultSet rs = ps.executeQuery();

			if(rs.next()){
				id = rs.getString(1);
				specilization = rs.getString(2);				
				
				doctorName= rs.getString(3);
				address = rs.getString(4);
				docFees = rs.getString(5);
				contactno = rs.getString(6);
				docEmail= rs.getString(7);
				password = rs.getString(5);
				

				flag = true;
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}	

		return flag;
	}
}