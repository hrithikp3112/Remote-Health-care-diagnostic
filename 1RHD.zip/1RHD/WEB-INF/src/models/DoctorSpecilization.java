package models;

import java.sql.*;
import java.util.*;
public class DoctorSpecilization{
	private String specilization;
	private String creationString;
	private String updationString;

	public String getSpecilization(){
		return specilization;
	}

	public void setSpecilization(String specilization){
		this.specilization=specilization;
	}

	public String getCreationString(){
		return creationString;
	}

	public void setCreationString(String creationString){
		this.creationString=creationString;
	}

	public String getUpdationString(){
		return updationString;
	}

	public void setUpdationString(String updationString){
		this.updationString=updationString;
	}
}