package models;

import java.sql.*;
import java.util.*;
public class Appointment{
	private String doctorSpecialization;
	private String doctorId;
	private String userId;
	private String consultancyFees;
	private String appoStringmentString;
	private String appoStringmentTime;
	private String postingString;
	private String userStatus;
	private String doctorStatus;
	private String updationString;

	public String getDoctorspecialization(){
		return doctorSpecialization;
	}

	public void setDoctorspecialization(String doctorSpecialization){
		this.doctorSpecialization=doctorSpecialization;
	}

	public String getDoctorid(){
		return doctorId;
	}

	public void setDoctorid(String doctorId){
		this.doctorId=doctorId;
	}

	public String getUserid(){
		return userId;
	}

	public void setUserid(String userId){
		this.userId=userId;
	}

	public String getConsultancyfees(){
		return consultancyFees;
	}

	public void setConsultancyfees(String consultancyFees){
		this.consultancyFees=consultancyFees;
	}

	public String getAppoStringmentString(){
		return appoStringmentString;
	}

	public void setAppoStringmentString(String appoStringmentString){
		this.appoStringmentString=appoStringmentString;
	}

	public String getAppoStringmenttime(){
		return appoStringmentTime;
	}

	public void setAppoStringmenttime(String appoStringmentTime){
		this.appoStringmentTime=appoStringmentTime;
	}

	public String getPostingString(){
		return postingString;
	}

	public void setPostingString(String postingString){
		this.postingString=postingString;
	}

	public String getUserstatus(){
		return userStatus;
	}

	public void setUserstatus(String userStatus){
		this.userStatus=userStatus;
	}

	public String getDoctorstatus(){
		return doctorStatus;
	}

	public void setDoctorstatus(String doctorStatus){
		this.doctorStatus=doctorStatus;
	}

	public String getUpdationString(){
		return updationString;
	}

	public void setUpdationString(String updationString){
		this.updationString=updationString;
	}
}