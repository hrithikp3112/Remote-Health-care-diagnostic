 package models;

import java.sql.*;
import java.util.*;
 public class Admin{
	private String username;
	private String password;
	private String updationString;
	private String id;

	public String getId(){
		return id;
	}

	public void setId(String id){
		this.id=id;
	}

	public String getUsername(){
		return username;
	}

	public void setUsername(String username){
		this.username=username;
	}

	public String getPassword(){
		return password;
	}

	public void setPassword(String password){
		this.password=password;
	}

	public String getUpdationString(){
		return updationString;
	}

	public void setUpdationString(String updationString){
		this.updationString=updationString;
	}

	public void registerUser(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms?user=root&password=1234");
			
			String q1 = "insert into admin (id,username,";
			String q2 = "password) value ";
			String q3 = "(?,?,?)";

			PreparedStatement ps = con.prepareStatement(q1+q2+q3);
			
			ps.setString(1,id);
			
			ps.setString(2,username);
			ps.setString(3,password);
			
			ps.executeUpdate();

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}


	public boolean loginDoctor(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select * from admin where email=? and password=?";

			PreparedStatement ps = con.prepareStatement(q1);
			ps.setString(1,id);
			ps.setString(1,username);
			ps.setString(2,password);

			ResultSet rs = ps.executeQuery();

			if(rs.next()){
				
				

				flag = true;
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}	

		return flag;
	}
}