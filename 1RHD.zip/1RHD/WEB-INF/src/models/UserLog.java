package models;

import java.sql.*;
import java.util.*;
public class UserLog{
	private String uid;
	private String username;
	private String logStringime;
	private String logout;
	private String status;

	public String getUid(){
		return uid;
	}

	public void setUid(String uid){
		this.uid=uid;
	}

	public String getUsername(){
		return username;
	}

	public void setUsername(String username){
		this.username=username;
	}

	public String getLogStringime(){
		return logStringime;
	}

	public void setLogStringime(String logStringime){
		this.logStringime=logStringime;
	}

	public String getLogout(){
		return logout;
	}

	public void setLogout(String logout){
		this.logout=logout;
	}

	public String getStatus(){
		return status;
	}

	public void setStatus(String status){
		this.status=status;
	}
}