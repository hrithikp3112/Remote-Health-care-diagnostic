package models;

import java.sql.*;
import java.util.*;
public class User{
	private String fullName;
	private String city;
	private String gender;
	private String email;
	private String address;
	private String password;
	private String id;
	private String regString;
	private String updationString;

	public String getId(){
		return id ;
	}

	public void setId(String id){
		this.id=id;
	}

	public String getAddress(){
		return address ;
	}

	public void setAddress(String address){
		this.address=address;
	}
	public String getFullname(){
		return fullName;
	}

	public void setFullname(String fullName){
		this.fullName=fullName;
	}

	public String getCity(){
		return city;
	}

	public void setCity(String city){
		this.city=city;
	}

	public String getGender(){
		return gender;
	}

	public void setGender(String gender){
		this.gender=gender;
	}

	public String getEmail(){
		return email;
	}

	public void setEmail(String email){
		this.email=email;
	}

	public String getPassword(){
		return password;
	}

	public void setPassword(String password){
		this.password=password;
	}

	public String getRegString(){
		return regString;
	}

	public void setRegString(String regString){
		this.regString=regString;
	}

	public String getUpdationString(){
		return updationString;
	}

	public void setUpdationString(String updationString){
		this.updationString=updationString;
	}

	public void registerUser(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms?user=root&password=1234");
			
			String q1 = "insert into users (id,fullName,";
			String q2 = "address,city,gender,email,password,regString,updationString) value ";
			String q3 = "(?,?,?,?,?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(q1+q2+q3);
			
			ps.setString(1,id);
			
			ps.setString(2,fullName);
			ps.setString(3,address);
			ps.setString(4,city);
			ps.setString(5,gender);
			ps.setString(6,email);
			ps.setString(7,password);
			ps.setString(8,regString);
			ps.setString(9,updationString);
			ps.executeUpdate();

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}


	public boolean loginDoctor(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select * from admin where email=? and password=?";

			PreparedStatement ps = con.prepareStatement(q1);
			ps.setString(1,id);
			ps.setString(2,fullName);
			ps.setString(3,address);
			ps.setString(4,city);
			ps.setString(5,gender);
			ps.setString(6,email);
			ps.setString(7,password);
			ps.setString(8,regString);
			ps.setString(9,updationString);
			



			ResultSet rs = ps.executeQuery();

			if(rs.next()){
				
				

				flag = true;
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}	

		return flag;
	}

	
}